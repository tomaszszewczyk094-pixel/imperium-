const $=id=>document.getElementById(id);
let socket,myId=null,world=[],players=[],monsters=[],groundItems=[],npcs=[];
const canvas=$("world"),ctx=canvas.getContext("2d");
const townMap=new Image();townMap.src="imperium-town.png";townMap.onload=draw;
const knightSheet=new Image();knightSheet.src="knight-sprites.png";knightSheet.onload=draw;
const creatureImages={};
["rat","troll","orc","dragon"].forEach(n=>{const im=new Image();im.src=n+".png";im.onload=draw;creatureImages[n]=im;});
function connect(){
 const address=$("server").value.trim().replace(/\/$/,"");
 if(!/^wss?:\/\//i.test(address)){$("loginError").textContent="Wpisz adres serwera ws:// lub wss://.";return;}
 localStorage.setItem("imperium_server",address);socket=new WebSocket(address);
 socket.onopen=()=>{$("status").textContent="POŁĄCZONO";socket.send(JSON.stringify({type:"auth",mode:$("authMode").value,username:$("account").value,password:$("password").value}));};
 socket.onclose=()=>{$("status").textContent="ROZŁĄCZONO";};
 socket.onerror=()=>{$("loginError").textContent="Nie udało się połączyć z serwerem.";};
 socket.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return;}
  if(m.type==="error"){$("loginError").textContent=m.message;return;}
  if(m.type==="auth_ok"){socket.send(JSON.stringify({type:"login",name:$("nick").value,vocation:$("vocation").value}));return;}
  if(m.type==="trade_invite"){if(confirm(`${m.from} proponuje wymianę: ${m.itemId} za ${m.gold} GP. Przyjąć?`))socket.send(JSON.stringify({type:"trade",action:"accept",offerId:m.id}));return;}
  if(m.type==="duel_invite"){if(confirm(`${m.from} wyzywa Cię na pojedynek. Przyjąć?`))socket.send(JSON.stringify({type:"duel",action:"accept",fromId:m.fromId}));return;}
  if(m.type==="guild_invite"){if(confirm(`${m.from} zaprasza Cię do gildii ${m.guildName}. Dołączyć?`))socket.send(JSON.stringify({type:"guild",action:"accept",guildId:m.guildId}));return;}
  if(m.type==="party_invite"){if(confirm(`${m.from} zaprasza Cię do drużyny. Przyjąć?`))socket.send(JSON.stringify({type:"party",action:"accept",target:m.from}));return;}
  if(m.type==="login_ok"){myId=m.id;$("gold").textContent=`${m.gold||0} GP`;$("login").hidden=true;$("game").hidden=false;$("charName").textContent=m.name;$("vocationName").textContent=m.vocationName||"Knight";resizeCanvas();draw();return;}
  if(m.type==="state"){if(m.zoneName)$("status").textContent=m.zoneName;world=m.world;players=m.players;monsters=m.monsters||[];groundItems=m.groundItems||[];npcs=m.npcs||[];const me=players.find(p=>p.id===myId);
   if(me){$("gold").textContent=`${me.gold||0} GP`;renderInventory(me);$("hunger").textContent=`SYTOŚĆ ${me.hunger??100}/100`;$("level").textContent=me.level;$("hp").textContent=`${me.hp}/${me.maxHp}`;$("mana").textContent=`MP ${me.mana}/${me.maxMana}`;$("hpBar").style.width=`${Math.max(0,Math.min(100,me.hp/me.maxHp*100))}%`;$("manaBar").style.width=`${me.mana/me.maxMana*100}%`;}
   draw();
  }
  if(m.type==="chat")addLine(`<b>${esc(m.name)}:</b> ${esc(m.text)}`);
  if(m.type==="system")addLine(`<span class="system">${esc(m.text)}</span>`);
 };
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function addLine(html){const p=document.createElement("p");p.innerHTML=html;$("log").appendChild(p);$("log").scrollTop=$("log").scrollHeight;}
function resizeCanvas(){const r=canvas.getBoundingClientRect(),d=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.max(320,Math.floor(r.width*d));canvas.height=Math.max(200,Math.floor(r.height*d));draw();}
function drawHero(x,y,isMe,cellW,cellH,p){
 if(knightSheet.complete&&knightSheet.naturalWidth){
  const row=({down:0,left:1,right:2,up:3})[p.dir]??0,walking=Date.now()<(p.walkUntil||0),frame=walking?(Math.floor(Date.now()/130)%3+1):0,sw=64,sh=64;
  const dw=Math.min(cellW*.90,cellH*1.05),dh=Math.min(cellH*1.45,cellW*1.18);ctx.imageSmoothingEnabled=false;
  ctx.drawImage(knightSheet,frame*sw,row*sh,sw,sh,x-dw/2,y-dh*.78,dw,dh);
  if(isMe){ctx.fillStyle="#f5d66e";ctx.beginPath();ctx.moveTo(x,y-dh*.94);ctx.lineTo(x-5,y-dh*1.12);ctx.lineTo(x+5,y-dh*1.12);ctx.closePath();ctx.fill();}
 }else{ctx.fillStyle="#2856a0";ctx.fillRect(x-7,y-12,14,20);}
}
function drawLoot(item,x,y,cw,ch){ctx.font=`bold ${Math.max(13,Math.round(ch*.42))}px Arial`;ctx.textAlign="center";ctx.lineWidth=3;ctx.strokeStyle="#171006";ctx.strokeText("✦",x,y);ctx.fillStyle="#ffd45e";ctx.fillText("✦",x,y);}
function drawMonster(m,x,y,cw,ch){
 const im=creatureImages[m.type];const sizes={rat:.64,troll:1.08,orc:1.05,dragon:1.35,wolf:1.0,skeleton:1.0,demon:1.2,boss:1.65};
 const dw=cw*(sizes[m.type]||1),dh=ch*(sizes[m.type]||1);
 if(im&&im.complete&&im.naturalWidth){ctx.imageSmoothingEnabled=false;ctx.drawImage(im,x-dw/2,y-dh*.78,dw,dh);}
 else{ctx.fillStyle=m.boss?"#7e1830":m.type==="demon"?"#a43b2d":m.type==="skeleton"?"#ded7bf":m.type==="wolf"?"#77705f":"#a8a04c";ctx.fillRect(x-dw/2,y-dh/2,dw,dh);}
 ctx.font=`bold ${Math.max(9,Math.round(ch*.24))}px Arial`;ctx.textAlign="center";ctx.lineWidth=3;ctx.strokeStyle="#120d08";
 ctx.strokeText(`${m.name} ${m.hp}/${m.maxHp}`,x,y-dh*.9);ctx.fillStyle="#ffb3a0";ctx.fillText(`${m.name} ${m.hp}/${m.maxHp}`,x,y-dh*.9);
}
function draw(){
 if(!ctx||!canvas.width||!canvas.height)return;
 const me=players.find(p=>p.id===myId),cols=20,rows=14,ox=me?Math.max(0,Math.min((world[0]?.length||40)-cols,me.x-10)):0,oy=me?Math.max(0,Math.min(world.length-rows,me.y-7)):0;
 ctx.clearRect(0,0,canvas.width,canvas.height);ctx.imageSmoothingEnabled=false;
 if(townMap.complete&&townMap.naturalWidth){const sw=townMap.naturalWidth*cols/40,sh=townMap.naturalHeight*rows/28,sx=townMap.naturalWidth*ox/40,sy=townMap.naturalHeight*oy/28;ctx.drawImage(townMap,sx,sy,sw,sh,0,0,canvas.width,canvas.height);}
 else{ctx.fillStyle="#47743b";ctx.fillRect(0,0,canvas.width,canvas.height);}
 const cw=canvas.width/cols,ch=canvas.height/rows;
 const actors=[...groundItems.map(it=>({...it,kind:"loot"})),...npcs.map(n=>({...n,kind:"npc"})),...monsters.map(m=>({...m,kind:"monster"})),...players.map(p=>({...p,kind:"player"}))].sort((a,b)=>a.y-b.y);
 actors.forEach(a=>{const gx=a.x-ox,gy=a.y-oy;if(gx<0||gy<0||gx>=cols||gy>=rows)return;const x=(gx+.5)*cw,y=(gy+.62)*ch;
  if(a.kind==="monster")drawMonster(a,x,y,cw,ch);
  else if(a.kind==="loot")drawLoot(a,x,y,cw,ch);
  else if(a.kind==="npc"){ctx.font=`bold ${Math.max(13,Math.round(ch*.38))}px Arial`;ctx.textAlign="center";ctx.fillStyle="#f4d36c";ctx.fillText("♙",x,y);ctx.font=`bold ${Math.max(9,Math.round(ch*.22))}px Arial`;ctx.fillText(a.name,x,y-ch*.45);}
  else{drawHero(x,y,a.id===myId,cw,ch,a);ctx.font=`bold ${Math.max(9,Math.round(ch*.28))}px Arial`;ctx.textAlign="center";ctx.lineWidth=3;ctx.strokeStyle="#10180b";const shownName=a.displayName||a.name;ctx.strokeText(shownName,x,y-ch*.55);ctx.fillStyle=a.id===myId?"#f5d66e":"#8df05c";ctx.fillText(a.mount?("🐎 "+shownName):shownName,x,y-ch*.55);}
 });
}
function move(dir){if(socket?.readyState===1)socket.send(JSON.stringify({type:"move",dir}));}
function attack(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"attack"}));}
function pickup(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"pickup"}));}
function castSpell(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"cast"}));}
function talkNpc(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"talk",npcId:"npc_guide"}));}
function openShop(){if(socket?.readyState!==1)return;const choice=prompt("Kupiec Jan — wpisz: bread, apple, meat, wooden_shield lub rusty_sword");if(choice)socket.send(JSON.stringify({type:"shop",action:"buy",itemId:choice.trim()}));}
function houseMenu(){if(socket?.readyState!==1)return;const a=prompt("DOMY: list — lista domów, buy — kup dom, info — mój dom, leave — oddaj dom");if(!a)return;const action=a.trim().toLowerCase();let houseId="";if(action==="buy")houseId=prompt("ID domu: house_01, house_02 lub house_03")||"";socket.send(JSON.stringify({type:"house",action,houseId}));}
function tradeMenu(){if(socket?.readyState!==1)return;const target=prompt("Nick gracza w pobliżu:");if(!target)return;const itemId=prompt("ID przedmiotu, który oferujesz:");if(!itemId)return;const gold=Number(prompt("Ile GP dorzucasz do swojej oferty? (0 jeśli bez dopłaty)")||0);socket.send(JSON.stringify({type:"trade",action:"offer",target:target.trim(),itemId:itemId.trim(),gold}));}
function bossInfo(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"boss"}));}
function questMenu(){if(socket?.readyState!==1)return;const a=prompt("ZADANIA: list, start_wolf, claim_wolf, start_cave, claim_cave");if(a)socket.send(JSON.stringify({type:"quest",action:a.trim().toLowerCase()}));}
function craftMenu(){if(socket?.readyState!==1)return;const id=prompt("RZEMIOSŁO — wooden_shield, rusty_sword, leather_armor, iron_sword, steel_armor, health_potion lub mana_potion");if(id)socket.send(JSON.stringify({type:"craft",itemId:id.trim()}));}
function bankMenu(){if(socket?.readyState!==1)return;const action=prompt("BANK: deposit_gold, withdraw_gold, deposit_item, withdraw_item");if(!action)return;let amount=0,itemId="";if(action.endsWith("gold"))amount=Number(prompt("Ile GP?"));else itemId=prompt("ID przedmiotu (np. bread, rusty_sword):")||"";socket.send(JSON.stringify({type:"bank",action,amount,itemId}));}
function travelMenu(){if(socket?.readyState!==1)return;const zone=prompt("Wybierz teren: town — Thais, forest — Zaczarowany Las, cave — Mroczna Jaskinia, catacombs — Zapomniane Katakumby");if(zone)socket.send(JSON.stringify({type:"travel",zone:zone.trim().toLowerCase()}));}
function pvpMenu(){if(socket?.readyState!==1)return;const target=prompt("Nick gracza, któremu chcesz zaproponować pojedynek:");if(target)socket.send(JSON.stringify({type:"duel",action:"challenge",target:target.trim()}));}
function pvpHit(){if(socket?.readyState!==1)return;const target=prompt("Nick przeciwnika z aktywnego pojedynku:");if(target)socket.send(JSON.stringify({type:"attack_player",target:target.trim()}));}
function guildMenu(){if(socket?.readyState!==1)return;const a=prompt("GILDIA: create — załóż, invite — zaproś, info — pokaż, leave — opuść");if(!a)return;const action=a.trim().toLowerCase();if(action==="create"){const name=prompt("Nazwa gildii:");if(name)socket.send(JSON.stringify({type:"guild",action,name}));}else if(action==="invite"){const target=prompt("Nick gracza:");if(target)socket.send(JSON.stringify({type:"guild",action,target}));}else if(["info","leave"].includes(action))socket.send(JSON.stringify({type:"guild",action}));}

function mountMenu(){if(socket?.readyState!==1)return;const a=prompt("WIERZCHOWCE: list, owned, buy, equip, dismount");if(!a)return;const action=a.trim().toLowerCase();let mountId="";if(["buy","equip"].includes(action))mountId=prompt("Wpisz: pony, wolf lub stag")||"";socket.send(JSON.stringify({type:"mount",action,mountId}));}
function achievementsMenu(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"achievements"}));}
function leaderboardMenu(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"leaderboard"}));}
function magicTrainingMenu(){if(socket?.readyState===1&&confirm("Trening magii zwiększa moc czarów. Kontynuować?"))socket.send(JSON.stringify({type:"magic_train"}));}
function eventMenu(){if(socket?.readyState!==1)return;const a=prompt("EVENT: status, start, join, finish");if(a)socket.send(JSON.stringify({type:"event",action:a.trim().toLowerCase()}));}
function mailMenu(){if(socket?.readyState!==1)return;const a=prompt("POCZTA: read, send, clear");if(!a)return;const action=a.trim().toLowerCase();if(action==="send"){const target=prompt("Nick odbiorcy:");const text=prompt("Treść wiadomości:");if(target&&text)socket.send(JSON.stringify({type:"mail",action,target,text}));}else socket.send(JSON.stringify({type:"mail",action}));}
function dailyMenu(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"daily"}));}
function bestiaryMenu(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"bestiary"}));}
function teleportMenu(){if(socket?.readyState!==1)return;const zone=prompt("Teleport: town, forest, cave lub catacombs (koszt 100 GP)");if(zone)socket.send(JSON.stringify({type:"teleport",zone:zone.trim().toLowerCase()}));}


function characterMenu(){if(socket?.readyState===1)socket.send(JSON.stringify({type:"character"}));}
function dailyTaskMenu(){if(socket?.readyState!==1)return;const a=prompt("ZADANIE DNIA: status lub claim");if(a)socket.send(JSON.stringify({type:"daily_task",action:a.trim().toLowerCase()}));}
function skillMenu(){if(socket?.readyState!==1)return;const skill=prompt("TRENING: melee, defense lub magic");if(skill)socket.send(JSON.stringify({type:"skill_train",skill:skill.trim().toLowerCase()}));}
function titleMenu(){if(socket?.readyState!==1)return;const a=prompt("TYTUŁY: wpisz list lub equip");if(!a)return;if(a.trim().toLowerCase()==="equip"){const name=prompt("Nazwa posiadanego tytułu:");if(name)socket.send(JSON.stringify({type:"title",action:"equip",name}));}else socket.send(JSON.stringify({type:"title",action:"list"}));}
function petMenu(){if(socket?.readyState!==1)return;const a=prompt("TOWARZYSZE: list, buy, equip, dismiss");if(!a)return;const action=a.trim().toLowerCase();let petId="";if(["buy","equip"].includes(action))petId=prompt("Wpisz: wolf, fox lub dragonling")||"";socket.send(JSON.stringify({type:"pet",action,petId}));}
function marketMenu(){if(socket?.readyState!==1)return;const a=prompt("RYNEK: list, sell lub buy");if(!a)return;const action=a.trim().toLowerCase();if(action==="sell"){const itemId=prompt("ID przedmiotu z plecaka:");const price=Number(prompt("Cena w GP:"));if(itemId)socket.send(JSON.stringify({type:"market",action,itemId,price}));}else if(action==="buy"){const listingId=prompt("ID oferty z listy:");if(listingId)socket.send(JSON.stringify({type:"market",action,listingId}));}else socket.send(JSON.stringify({type:"market",action:"list"}));}
function storyMenu(){if(socket?.readyState!==1)return;const a=prompt("FABUŁA: status lub advance");if(a)socket.send(JSON.stringify({type:"story",action:a.trim().toLowerCase()}));}
function usePotion(){if(socket?.readyState!==1)return;const id=prompt("MIKSTURY: health_potion, mana_potion, great_potion");if(id)socket.send(JSON.stringify({type:"use_item",itemId:id.trim().toLowerCase()}));}

function partyInvite(){if(socket?.readyState!==1)return;const target=prompt("Podaj nick gracza stojącego blisko Ciebie:");if(target)socket.send(JSON.stringify({type:"party",action:"invite",target:target.trim()}));}
const itemInfo={oak_club:{name:"Dębowa pałka",slot:"weapon",icon:"🪵",atk:2,def:0},rusty_sword:{name:"Zardzewiały miecz",slot:"weapon",icon:"⚔",atk:4,def:0},wooden_shield:{name:"Drewniana tarcza",slot:"shield",icon:"🛡",atk:0,def:3},leather_armor:{name:"Skórzana zbroja",slot:"armor",icon:"🥋",atk:0,def:2},leather_helmet:{name:"Skórzany hełm",slot:"helmet",icon:"⛑",atk:0,def:1},leather_legs:{name:"Skórzane nogawice",slot:"legs",icon:"👖",atk:0,def:1},leather_boots:{name:"Skórzane buty",slot:"boots",icon:"🥾",atk:0,def:1},small_backpack:{name:"Mały plecak",slot:"backpack",icon:"🎒",atk:0,def:0},bread:{name:"Chleb",slot:"food",icon:"🍞",atk:0,def:0},apple:{name:"Jabłko",slot:"food",icon:"🍎",atk:0,def:0},meat:{name:"Mięso",slot:"food",icon:"🍖",atk:0,def:0},health_potion:{name:"Mikstura zdrowia",slot:"consumable",icon:"🧪",atk:0,def:0},mana_potion:{name:"Mikstura many",slot:"consumable",icon:"🔵",atk:0,def:0},great_potion:{name:"Wielka mikstura",slot:"consumable",icon:"✨",atk:0,def:0},iron_sword:{name:"Żelazny miecz",slot:"weapon",icon:"⚔",atk:12,def:0},steel_armor:{name:"Stalowa zbroja",slot:"armor",icon:"🛡",atk:0,def:10},crystal:{name:"Kryształ many",slot:"material",icon:"💎",atk:0,def:0},ancient_rune:{name:"Starożytna runa",slot:"material",icon:"🔮",atk:0,def:0}};
const slotNames={weapon:"Broń",shield:"Tarcza",helmet:"Hełm",armor:"Zbroja",legs:"Nogawice",boots:"Buty",backpack:"Plecak"};
function renderInventory(me){
 const eq=$("equipmentGrid"),bag=$("bagGrid");if(!eq||!bag)return;
 const equipment=me.equipment||{},inventory=me.inventory||[];let atk=0,def=0;
 eq.innerHTML=Object.keys(slotNames).map(slot=>{const id=equipment[slot],it=itemInfo[id];if(it){atk+=it.atk;def+=it.def;}
  return `<button class="equip-slot ${id?"filled":"empty"}" data-unequip="${slot}"><span>${slotNames[slot]}</span><b>${it?it.icon+" "+it.name:"— puste —"}</b><small>${id?"Dotknij, aby zdjąć":"Miejsce na przedmiot"}</small></button>`;
 }).join("");
 bag.innerHTML=inventory.length?inventory.map(id=>{const it=itemInfo[id];if(!it)return "";return it.slot==="food"?`<button class="bag-item" data-eat="${id}"><b>${it.icon} ${it.name}</b><small>Pożywienie</small><em>DOTKNIJ, ABY ZJEŚĆ</em></button>`:it.slot==="consumable"?`<button class="bag-item" data-potion="${id}"><b>${it.icon} ${it.name}</b><small>Mikstura</small><em>DOTKNIJ, ABY UŻYĆ</em></button>`:it.slot==="material"?`<div class="bag-item"><b>${it.icon} ${it.name}</b><small>Składnik rzemieślniczy</small></div>`:`<button class="bag-item" data-equip="${id}"><b>${it.icon} ${it.name}</b><small>${slotNames[it.slot]||it.slot} • ATK +${it.atk} • DEF +${it.def}</small><em>DOTKNIJ, ABY ZAŁOŻYĆ</em></button>`;}).join(""):`<div class="bag-empty">Plecak jest pusty.</div>`;
 $("combatStats").textContent=`ATK +${atk} • DEF +${def}`;
}
const saved=localStorage.getItem("imperium_server");if(saved)$("server").value=saved;
const vocationDescriptions={knight:"Wytrzymały wojownik walczący w zwarciu. Najwięcej punktów życia i mocne uderzenia.",paladin:"Wszechstronny łucznik. Dobry balans życia, many i obrażeń.",druid:"Mag natury. Więcej many, wsparcie i leczenie — zaklęcia do rozbudowy w kolejnym etapie.",sorcerer:"Mag ofensywny. Największy zapas many i moc zaklęć — system czarów będzie rozwijany dalej."};
$("vocation").addEventListener("change",()=>{$("vocationInfo").textContent=vocationDescriptions[$("vocation").value];});
$("play").onclick=()=>{if($("nick").value.trim().length<3){$("loginError").textContent="Nick musi mieć co najmniej 3 znaki.";return;}connect();};
document.querySelectorAll("[data-dir]").forEach(b=>b.addEventListener("pointerdown",e=>{e.preventDefault();move(b.dataset.dir);}));
$("attackBtn").addEventListener("click",attack);
$("pickupBtn").addEventListener("click",pickup);
$("spellBtn").addEventListener("click",castSpell);
if($("talkBtn"))$("talkBtn").addEventListener("click",talkNpc);
if($("shopBtn"))$("shopBtn").addEventListener("click",openShop);
if($("partyBtn"))$("partyBtn").addEventListener("click",partyInvite);
if($("guildBtn"))$("guildBtn").addEventListener("click",guildMenu);
if($("pvpBtn"))$("pvpBtn").addEventListener("click",pvpMenu);
if($("pvpHitBtn"))$("pvpHitBtn").addEventListener("click",pvpHit);
if($("travelBtn"))$("travelBtn").addEventListener("click",travelMenu);
if($("bankBtn"))$("bankBtn").addEventListener("click",bankMenu);
if($("craftBtn"))$("craftBtn").addEventListener("click",craftMenu);
if($("houseBtn"))$("houseBtn").addEventListener("click",houseMenu);
if($("tradeBtn"))$("tradeBtn").addEventListener("click",tradeMenu);
if($("bossBtn"))$("bossBtn").addEventListener("click",bossInfo);
if($("questBtn"))$("questBtn").addEventListener("click",questMenu);

if($("mountBtn"))$("mountBtn").addEventListener("click",mountMenu);
if($("achievementBtn"))$("achievementBtn").addEventListener("click",achievementsMenu);
if($("rankBtn"))$("rankBtn").addEventListener("click",leaderboardMenu);
if($("magicTrainBtn"))$("magicTrainBtn").addEventListener("click",magicTrainingMenu);
if($("eventBtn"))$("eventBtn").addEventListener("click",eventMenu);
if($("mailBtn"))$("mailBtn").addEventListener("click",mailMenu);
if($("dailyBtn"))$("dailyBtn").addEventListener("click",dailyMenu);
if($("bestiaryBtn"))$("bestiaryBtn").addEventListener("click",bestiaryMenu);
if($("teleportBtn"))$("teleportBtn").addEventListener("click",teleportMenu);


if($("characterBtn"))$("characterBtn").addEventListener("click",characterMenu);
if($("dailyTaskBtn"))$("dailyTaskBtn").addEventListener("click",dailyTaskMenu);
if($("skillBtn"))$("skillBtn").addEventListener("click",skillMenu);
if($("titleBtn"))$("titleBtn").addEventListener("click",titleMenu);
if($("petBtn"))$("petBtn").addEventListener("click",petMenu);
if($("marketBtn"))$("marketBtn").addEventListener("click",marketMenu);
if($("storyBtn"))$("storyBtn").addEventListener("click",storyMenu);
if($("potionBtn"))$("potionBtn").addEventListener("click",usePotion);

document.addEventListener("click",e=>{const equip=e.target.closest("[data-equip]"),unequip=e.target.closest("[data-unequip]"),eat=e.target.closest("[data-eat]"),potion=e.target.closest("[data-potion]");if(socket?.readyState!==1)return;if(eat)socket.send(JSON.stringify({type:"eat",itemId:eat.dataset.eat}));else if(potion)socket.send(JSON.stringify({type:"use_item",itemId:potion.dataset.potion}));else if(equip)socket.send(JSON.stringify({type:"equip",itemId:equip.dataset.equip}));else if(unequip)socket.send(JSON.stringify({type:"unequip",slot:unequip.dataset.unequip}));});
window.addEventListener("keydown",e=>{const map={ArrowUp:"up",w:"up",ArrowDown:"down",s:"down",ArrowLeft:"left",a:"left",ArrowRight:"right",d:"right"};if(map[e.key]){e.preventDefault();move(map[e.key]);}if(e.key===" "){e.preventDefault();attack();}});
$("chatForm").onsubmit=e=>{e.preventDefault();const t=$("chatInput").value.trim();if(t&&socket?.readyState===1)socket.send(JSON.stringify({type:"chat",text:t}));$("chatInput").value="";};
window.addEventListener("resize",resizeCanvas);if(window.visualViewport)window.visualViewport.addEventListener("resize",resizeCanvas);
function animate(){if(!$("game").hidden&&players.some(p=>Date.now()<(p.walkUntil||0)))draw();requestAnimationFrame(animate);}requestAnimationFrame(animate);
