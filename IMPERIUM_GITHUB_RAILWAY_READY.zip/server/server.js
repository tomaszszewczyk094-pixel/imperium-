const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT || 8080);
const DATA_DIR = process.env.DATA_DIR || __dirname;
fs.mkdirSync(DATA_DIR, { recursive: true });
const PUBLIC = path.join(__dirname, "public");
const WORLD_W = 40, WORLD_H = 28;
const players = new Map();
const SAVE_FILE = path.join(DATA_DIR, "characters.json");
const ACCOUNT_FILE = path.join(DATA_DIR, "accounts.json");
const GUILD_FILE=path.join(DATA_DIR,"guilds.json");
const HOUSE_FILE=path.join(DATA_DIR,"houses.json");
const houses={};try{Object.assign(houses,JSON.parse(fs.readFileSync(HOUSE_FILE,"utf8")));}catch{}
function saveHouses(){fs.writeFileSync(HOUSE_FILE,JSON.stringify(houses,null,2));}
const tradeOffers=new Map();
const MAIL_FILE=path.join(DATA_DIR,"mail.json");
let mailboxes={};try{mailboxes=JSON.parse(fs.readFileSync(MAIL_FILE,"utf8"));}catch{mailboxes={};}
function saveMail(){fs.writeFileSync(MAIL_FILE,JSON.stringify(mailboxes,null,2));}
let worldEvent={active:false,name:"",participants:[],startedAt:0};
const dailyClaims=new Set();
let guilds={};try{guilds=JSON.parse(fs.readFileSync(GUILD_FILE,"utf8"));}catch{guilds={};}
function saveGuilds(){fs.writeFileSync(GUILD_FILE,JSON.stringify(guilds,null,2));}
let accounts = {};
try { accounts = JSON.parse(fs.readFileSync(ACCOUNT_FILE, "utf8")); } catch { accounts = {}; }
function saveAccounts(){ fs.writeFileSync(ACCOUNT_FILE, JSON.stringify(accounts,null,2), {mode:0o600}); }
function accountKey(s){ return String(s||"").trim().toLowerCase(); }
function hashPassword(password,salt){ return crypto.scryptSync(password,salt,64).toString("hex"); }
function safeEqual(a,b){ const aa=Buffer.from(a,"hex"),bb=Buffer.from(b,"hex"); return aa.length===bb.length && crypto.timingSafeEqual(aa,bb); }
let savedCharacters = {};
try { savedCharacters = JSON.parse(fs.readFileSync(SAVE_FILE, "utf8")); } catch { savedCharacters = {}; }
function saveCharacter(p){
 if(!p)return;
 const {ws,lastMove,lastAttack,lastSpell,lastHungerDamage,...data}=p;
 savedCharacters[p.name.toLowerCase()] = data;
 try { fs.writeFileSync(SAVE_FILE, JSON.stringify(savedCharacters,null,2)); }
 catch(err){ console.error("Nie udało się zapisać postaci:",err.message); }
}
const monsters = new Map();
const groundItems = new Map();
const npcList=[{id:"npc_guide",name:"Strażnik Marek",x:22,y:14,role:"quest"},{id:"npc_shop",name:"Kupiec Jan",x:18,y:14,role:"shop"}];
let nextGroundItemId = 1;
const world = Array.from({length: WORLD_H}, (_, y) =>
  Array.from({length: WORLD_W}, (_, x) => {
    if (x === 0 || y === 0 || x === WORLD_W-1 || y === WORLD_H-1) return 1;
    if ((x*13 + y*7) % 47 === 0) return 2;
    return 0;
  })
);
const zoneNames={town:"Thais — Miasto",forest:"Zaczarowany Las",cave:"Mroczna Jaskinia",catacombs:"Zapomniane Katakumby"};
function makeZone(zone){return Array.from({length:WORLD_H},(_,y)=>Array.from({length:WORLD_W},(_,x)=>{if(x===0||y===0||x===WORLD_W-1||y===WORLD_H-1)return 1;const v=(x*7+y*11)%17;return zone==="forest"?(v===0?2:0):zone==="cave"?(v===0||v===1?2:0):world[y][x];}));}
const zoneMaps={town:world,forest:makeZone("forest"),cave:makeZone("cave"),catacombs:makeZone("cave")};
const monsterTypes = [
  {type:"rat", name:"Rat", hp:18, exp:5, x:12,y:12},
  {type:"rat", name:"Rat", hp:18, exp:5, x:15,y:17},
  {type:"troll", name:"Troll", hp:85, exp:20, x:27,y:9},
  {type:"orc", name:"Orc", hp:100, exp:25, x:31,y:19},
  {type:"dragon", name:"Dragon", hp:500, exp:200, x:34,y:7},
 {type:"orc",name:"Leśny Orc",hp:115,exp:32,x:10,y:10,zone:"forest"},{type:"troll",name:"Leśny Troll",hp:95,exp:28,x:26,y:18,zone:"forest"},{type:"dragon",name:"Jaskiniowy Smok",hp:620,exp:260,x:30,y:8,zone:"cave"},{type:"orc",name:"Jaskiniowy Orc",hp:140,exp:40,x:12,y:20,zone:"cave"}
];
monsterTypes.push(
 {type:"wolf",name:"Wilk",hp:65,exp:22,x:8,y:18,zone:"forest"},
 {type:"skeleton",name:"Szkielet",hp:105,exp:38,x:31,y:13,zone:"cave"},
 {type:"demon",name:"Demon",hp:260,exp:95,x:34,y:22,zone:"cave"},
 {type:"boss",name:"Władca Otchłani",hp:1800,exp:900,x:34,y:24,zone:"cave",boss:true},
 {type:"skeleton",name:"Strażnik Katakumb",hp:240,exp:110,x:12,y:12,zone:"catacombs"},
 {type:"demon",name:"Upiorny Demon",hp:420,exp:180,x:29,y:18,zone:"catacombs"},
 {type:"boss",name:"Król Umarłych",hp:3200,exp:1800,x:34,y:24,zone:"catacombs",boss:true}
);
let nextMonsterId=1;
function spawnMonster(spec){
  const id="m"+nextMonsterId++;
  monsters.set(id,{id,type:spec.type,name:spec.name,boss:!!spec.boss,zone:spec.zone||"town",hp:spec.hp,maxHp:spec.hp,exp:spec.exp,x:spec.x,y:spec.y,respawn:spec});
}
monsterTypes.forEach(spawnMonster);

const mime={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".png":"image/png"};
const server=http.createServer((req,res)=>{
  if(req.url==="/health" || req.url==="/healthz"){
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify({status:"ok",game:"IMPERIUM",players:players.size}));
  }
  if(req.url==="/" ){
    res.writeHead(200,{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"no-store"});
    return res.end("IMPERIUM game server is running. Connect with WebSocket.");
  }
  let pathname=decodeURIComponent((req.url||"/").split("?")[0]);
  if(pathname==="/") pathname="/index.html";
  const file=path.join(PUBLIC,pathname.replace(/^\/+/,""));
  if(!file.startsWith(PUBLIC)){res.writeHead(403);return res.end("Forbidden");}
  fs.readFile(file,(err,data)=>{if(err){res.writeHead(404);return res.end("Not found");}
    res.writeHead(200,{"Content-Type":mime[path.extname(file)]||"application/octet-stream","Cache-Control":"no-store"});res.end(data);});
});
const wss=new WebSocket.Server({server, maxPayload: 64 * 1024});
function send(ws,obj){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));}
function broadcast(obj){for(const p of players.values())send(p.ws,obj?.type==="state"?snapshot(p.zone):obj);}
function publicPlayer(p){const {ws,lastMove,...safe}=p;safe.achievements=earnedAchievements(p);safe.displayName=p.title?`${p.title} ${p.name}`:p.name;return safe;}
function snapshot(zone="town"){return {type:"state",world:zoneMaps[zone||"town"],zoneName:zoneNames[zone||"town"],npcs:zone==="town"?npcList:[],players:[...players.values()].filter(p=>(p.zone||"town")===(zone||"town")).map(publicPlayer),guilds:Object.values(guilds).map(g=>({id:g.id,name:g.name,leader:g.leader,members:g.members})),monsters:[...monsters.values()].filter(m=>(m.zone||"town")===(zone||"town")).map(({respawn,...m})=>m),groundItems:[...groundItems.values()].filter(it=>(it.zone||"town")===(zone||"town"))};}
function earnedAchievements(p){
 const out=[];
 if((p.level||1)>=5)out.push("Początkujący bohater");
 if((p.level||1)>=10)out.push("Weteran Imperium");
 if((p.gold||0)>=1000)out.push("Zamożny podróżnik");
 if(p.quest?.wolfHunt==="completed")out.push("Pogromca wilków");
 if(p.quest?.caveHunt==="completed")out.push("Badacz krypty");
 if((p.bestiary?.boss||0)>=1)out.push("Łowca bossów");
 return out;
}
function itemStats(p){let attack=0,defense=0;for(const id of Object.values(p.equipment)){const it=itemCatalog[id];if(it){attack+=it.attack;defense+=it.defense;}}defense+=Math.max(0,(p.skills?.defense||1)-1);return {attack,defense};}
function respawnPlayer(p){p.x=20;p.y=14;p.hp=p.maxHp;p.mana=p.maxMana;p.dead=false;p.walkUntil=0;announce(`${p.name} wraca do miasta i odzyskuje siły.`);broadcast(snapshot());}
function cleanName(s){return String(s||"").trim().replace(/[^a-zA-Z0-9 _-]/g,"").slice(0,16);}
function announce(text){broadcast({type:"system",text});}
const itemCatalog = {
  rusty_sword:{id:"rusty_sword",name:"Zardzewiały miecz",slot:"weapon",attack:4,defense:0,description:"Prosty miecz początkującego wojownika."},
  oak_club:{id:"oak_club",name:"Dębowa pałka",slot:"weapon",attack:2,defense:0,description:"Lekka broń do walki."},
  wooden_shield:{id:"wooden_shield",name:"Drewniana tarcza",slot:"shield",attack:0,defense:3,description:"Podstawowa osłona."},
  leather_armor:{id:"leather_armor",name:"Skórzana zbroja",slot:"armor",attack:0,defense:2,description:"Lekka ochrona tułowia."},
  leather_helmet:{id:"leather_helmet",name:"Skórzany hełm",slot:"helmet",attack:0,defense:1,description:"Chroni głowę."},
  leather_legs:{id:"leather_legs",name:"Skórzane nogawice",slot:"legs",attack:0,defense:1,description:"Podstawowa ochrona nóg."},
  leather_boots:{id:"leather_boots",name:"Skórzane buty",slot:"boots",attack:0,defense:1,description:"Wygodne buty podróżne."},
  small_backpack:{id:"small_backpack",name:"Mały plecak",slot:"backpack",attack:0,defense:0,description:"Mieści ekwipunek podróżnika."},
  bread:{id:"bread",name:"Chleb",slot:"food",attack:0,defense:0,food:30,description:"Przywraca sytość."},
  apple:{id:"apple",name:"Jabłko",slot:"food",attack:0,defense:0,food:18,description:"Lekka przekąska."},
  meat:{id:"meat",name:"Mięso",slot:"food",attack:0,defense:0,food:45,description:"Pożywny posiłek."},
 health_potion:{id:"health_potion",name:"Mikstura zdrowia",slot:"consumable",attack:0,defense:0,heal:80,description:"Przywraca do 80 HP."},
 mana_potion:{id:"mana_potion",name:"Mikstura many",slot:"consumable",attack:0,defense:0,mana:70,description:"Przywraca do 70 MP."},
 great_potion:{id:"great_potion",name:"Wielka mikstura",slot:"consumable",attack:0,defense:0,heal:160,mana:120,description:"Przywraca HP i MP."},
 iron_sword:{id:"iron_sword",name:"Żelazny miecz",slot:"weapon",attack:12,defense:0,description:"Solidna broń doświadczonego wojownika."},
 steel_armor:{id:"steel_armor",name:"Stalowa zbroja",slot:"armor",attack:0,defense:10,description:"Ciężka zbroja z dobrej stali."},
 crystal:{id:"crystal",name:"Kryształ many",slot:"material",attack:0,defense:0,description:"Rzadki składnik magiczny."},
 ancient_rune:{id:"ancient_rune",name:"Starożytna runa",slot:"material",attack:0,defense:0,description:"Runa z ruin Imperium."}
};
const equipmentSlots = ["weapon","shield","helmet","armor","legs","boots","backpack"];
const vocations = {
 knight:{label:"Knight",hp:150,mana:50,damage:16},
 paladin:{label:"Paladin",hp:120,mana:80,damage:12},
 druid:{label:"Druid",hp:95,mana:135,damage:9},
 sorcerer:{label:"Sorcerer",hp:90,mana:145,damage:11}
};
wss.on("connection",ws=>{
 let player=null, authenticatedAccount=null;
 send(ws,{type:"hello",message:"Witaj w IMPERIUM"});
 ws.on("message",raw=>{
  let msg;try{msg=JSON.parse(raw.toString());}catch{return;}
  if(!player){
   if(msg.type==="auth"){
    const username=String(msg.username||"").trim(); const key=accountKey(username); const password=String(msg.password||"");
    if(!/^[a-zA-Z0-9_]{3,20}$/.test(username) || password.length<8 || password.length>128){send(ws,{type:"error",message:"Login: 3–20 znaków (litery/cyfry/_), hasło: 8–128 znaków."});return;}
    if(msg.mode==="register"){
     if(accounts[key]){send(ws,{type:"error",message:"To konto już istnieje."});return;}
     const salt=crypto.randomBytes(16).toString("hex");accounts[key]={username,salt,hash:hashPassword(password,salt),createdAt:Date.now()};saveAccounts();
    }else if(msg.mode==="login"){
     const acc=accounts[key];if(!acc||!safeEqual(hashPassword(password,acc.salt),acc.hash)){send(ws,{type:"error",message:"Nieprawidłowy login lub hasło."});return;}
    }else return;
    authenticatedAccount=key;send(ws,{type:"auth_ok",username});return;
   }
   if(msg.type!=="login" || !authenticatedAccount)return;
   const name=cleanName(msg.name);
   const vocation=vocations[msg.vocation] ? msg.vocation : "knight";
   const stats=vocations[vocation];
   if(name.length<3)return send(ws,{type:"error",message:"Nick musi mieć 3–16 znaków."});
   if([...players.values()].some(p=>p.name.toLowerCase()===name.toLowerCase()))return send(ws,{type:"error",message:"Ta postać jest już zalogowana."});
   const saved=savedCharacters[name.toLowerCase()];
   if(saved?.ownerAccount && saved.ownerAccount!==authenticatedAccount)return send(ws,{type:"error",message:"Ta postać należy do innego konta."});
   player={id:crypto.randomUUID(),ownerAccount:authenticatedAccount,name,guildId:saved?.guildId||null,houseId:saved?.houseId||null,mount:saved?.mount||null,magicLevel:saved?.magicLevel||0,
    achievements:saved?.achievements||[],bestiary:saved?.bestiary||{},title:saved?.title||"",
    quest:{...(saved?.quest||{}),ratHunt:saved?.quest?.ratHunt||"not_started",ratKills:saved?.quest?.ratKills||0},
     skills:saved?.skills||{melee:1,defense:1,magic:1},titles:saved?.titles||["Nowicjusz"],title:saved?.title||"Nowicjusz",
     pet:saved?.pet||null,pets:saved?.pets||[],dailyTask:saved?.dailyTask||null,unlockedZones:saved?.unlockedZones||["town","forest","cave"],
     marketListings:saved?.marketListings||[],story:saved?.story||{chapter:0,finalClaimed:false},vocation:saved?.vocation||vocation,vocationName:saved?.vocationName||stats.label,x:saved?.x??20,y:saved?.y??14,zone:saved?.zone||"town",hp:saved?.hp??stats.hp,maxHp:saved?.maxHp??stats.hp,mana:saved?.mana??stats.mana,maxMana:saved?.maxMana??stats.mana,level:saved?.level??1,exp:saved?.exp??0,dir:saved?.dir||"down",walkUntil:0,
    inventory:saved?.inventory||["rusty_sword","wooden_shield","leather_armor","leather_helmet","leather_legs","leather_boots","small_backpack","bread","bread","apple"],hunger:saved?.hunger??100,gold:saved?.gold??100,bankGold:saved?.bankGold??0,bank:saved?.bank||[],dailyDate:saved?.dailyDate||"",dailyStreak:saved?.dailyStreak||0,
    
    equipment:saved?.equipment||{weapon:null,shield:null,helmet:null,armor:null,legs:null,boots:null,backpack:null},ws,lastMove:0,lastAttack:0,dead:false};
   players.set(player.id,player);
   send(ws,{type:"login_ok",id:player.id,name:player.name,vocation:player.vocation,vocationName:player.vocationName,gold:player.gold});
   announce(`${name} (${player.vocationName}) dołącza do Imperium.`);
   broadcast(snapshot());return;
  }
  if(player.dead){if(msg.type==="chat"){}else return;}
  if(msg.type==="move"){
   if(player.dead)return;
   const now=Date.now();if(now-player.lastMove<(player.mount?85:110))return;player.lastMove=now;
   const dirs={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]},d=dirs[msg.dir];if(!d)return;
   player.dir=msg.dir;
   const nx=player.x+d[0],ny=player.y+d[1];
   if(nx<1||ny<1||nx>=WORLD_W-1||ny>=WORLD_H-1||zoneMaps[player.zone||"town"][ny][nx]!==0)return;
   player.x=nx;player.y=ny;player.walkUntil=now+240;broadcast(snapshot());
  } else if(msg.type==="attack"){
   if(player.dead)return;
   if(Date.now()-player.lastAttack<650)return;player.lastAttack=Date.now();
   const target=[...monsters.values()].filter(m=>(m.zone||"town")===(player.zone||"town")&&Math.abs(m.x-player.x)+Math.abs(m.y-player.y)<=1)
     .sort((a,b)=>Math.abs(a.x-player.x)+Math.abs(a.y-player.y)-Math.abs(b.x-player.x)-Math.abs(b.y-player.y))[0];
   if(!target){send(ws,{type:"system",text:"Podejdź bliżej potwora, aby zaatakować."});return;}
   const petBonus={wolf:2,fox:3,dragonling:5}[player.pet]||0;
    const damage=vocations[player.vocation].damage+player.level*2+itemStats(player).attack+(player.skills?.melee||1)-1+petBonus;
   target.hp-=damage;
   announce(`${player.name} trafia ${target.name} za ${damage} obrażeń.`);
   if(target.hp<=0){
    const dead=target;monsters.delete(dead.id);player.bestiary=player.bestiary||{};player.bestiary[dead.type]=(player.bestiary[dead.type]||0)+1;
     if(player.dailyTask&&player.dailyTask.day===new Date().toISOString().slice(0,10)&&player.dailyTask.type===dead.type&&!player.dailyTask.claimed)player.dailyTask.kills=Math.min(player.dailyTask.goal,player.dailyTask.kills+1);
     player.exp+=dead.exp; if(player.quest?.wolfHunt==="active"&&dead.type==="wolf")player.quest.wolfKills=(player.quest.wolfKills||0)+1; if(player.quest?.caveHunt==="active"&&["skeleton","demon"].includes(dead.type))player.quest.caveKills=(player.quest.caveKills||0)+1; if(dead.boss){player.gold=(player.gold||0)+500;player.inventory.push("rusty_sword");announce(`${player.name} pokonuje bossa i zdobywa 500 GP oraz rzadki łup!`);}
     if(dead.name==="Król Umarłych"){player.story=player.story||{chapter:0,finalClaimed:false};player.story.krKingDefeated=true;player.inventory.push("ancient_rune","crystal");saveCharacter(player);announce(`${player.name} zdobywa runę i kryształ po pokonaniu Króla Umarłych!`);}
    const drops={rat:["oak_club","leather_boots"],troll:["wooden_shield","leather_armor"],orc:["rusty_sword","leather_helmet"],dragon:["leather_legs","rusty_sword"],skeleton:["crystal","leather_helmet"],demon:["crystal","ancient_rune"],boss:["ancient_rune","crystal"]};
    const choices=drops[dead.type]||["oak_club"];const dropId=choices[Math.floor(Math.random()*choices.length)];const drop=itemCatalog[dropId];
    const groundId="g"+nextGroundItemId++;groundItems.set(groundId,{id:groundId,itemId:dropId,name:drop.name,x:dead.x,y:dead.y,zone:dead.zone||"town"});
    announce(`${dead.name} upuszcza przedmiot: ${drop.name}.`);
    if(dead.type==="rat" && player.quest?.ratHunt==="active")player.quest.ratKills=Math.min(3,(player.quest.ratKills||0)+1);
    announce(`${player.name} pokonuje ${dead.name}. Zdobywa ${dead.exp} EXP.`);
    while(player.exp>=player.level*100){player.exp-=player.level*100;player.level++;player.maxHp+=player.vocation==="knight"?15:player.vocation==="paladin"?12:8;player.maxMana+=player.vocation==="knight"?3:player.vocation==="paladin"?7:15;player.hp=player.maxHp;player.mana=player.maxMana;announce(`${player.name} awansuje na poziom ${player.level}!`);}
    setTimeout(()=>{spawnMonster(dead.respawn);broadcast(snapshot());},12000);
   }
   broadcast(snapshot());
  } else if(msg.type==="cast"){
   if(player.dead)return;
   const now=Date.now();
   if(now-(player.lastSpell||0)<900){send(ws,{type:"system",text:"Odczekaj chwilę przed kolejnym czarem."});return;}
   const spells={
    druid:{name:"Exura",mana:25,kind:"heal",power:35},
    sorcerer:{name:"Exori Flam",mana:20,kind:"damage",power:36},
    paladin:{name:"Exori San",mana:15,kind:"damage",power:22}
   };
   const spell=spells[player.vocation];if(spell)spell.power+=Math.min(20,(player.magicLevel||0)*4);
   if(!spell){send(ws,{type:"system",text:"Twoja profesja nie zna jeszcze czarów."});return;}
   if(player.mana<spell.mana){send(ws,{type:"system",text:`Za mało many. Potrzebujesz ${spell.mana} MP.`});return;}
   player.lastSpell=now;player.mana-=spell.mana;
   if(spell.kind==="heal"){
    const before=player.hp;player.hp=Math.min(player.maxHp,player.hp+spell.power);
    announce(`${player.name} używa ${spell.name} i odzyskuje ${player.hp-before} HP.`);
   }else{
    const target=[...monsters.values()].filter(m=>(m.zone||"town")===(player.zone||"town")&&Math.abs(m.x-player.x)+Math.abs(m.y-player.y)<=3)
     .sort((a,b)=>(Math.abs(a.x-player.x)+Math.abs(a.y-player.y))-(Math.abs(b.x-player.x)+Math.abs(b.y-player.y)))[0];
    if(!target){player.mana+=spell.mana;player.lastSpell=0;send(ws,{type:"system",text:"Nie ma potwora w zasięgu czaru (3 pola)."});return;}
    const damage=spell.power+player.level+((player.skills?.magic||1)-1)*2;
    target.hp-=damage;announce(`${player.name} rzuca ${spell.name} na ${target.name}: ${damage} obrażeń.`);
    if(target.hp<=0){
     const dead=target;monsters.delete(dead.id);player.bestiary=player.bestiary||{};player.bestiary[dead.type]=(player.bestiary[dead.type]||0)+1;
     if(player.dailyTask&&player.dailyTask.day===new Date().toISOString().slice(0,10)&&player.dailyTask.type===dead.type&&!player.dailyTask.claimed)player.dailyTask.kills=Math.min(player.dailyTask.goal,player.dailyTask.kills+1);
     player.exp+=dead.exp; if(player.quest?.wolfHunt==="active"&&dead.type==="wolf")player.quest.wolfKills=(player.quest.wolfKills||0)+1; if(player.quest?.caveHunt==="active"&&["skeleton","demon"].includes(dead.type))player.quest.caveKills=(player.quest.caveKills||0)+1; if(dead.boss){player.gold=(player.gold||0)+500;player.inventory.push("rusty_sword");announce(`${player.name} pokonuje bossa i zdobywa 500 GP oraz rzadki łup!`);}
     if(dead.name==="Król Umarłych"){player.story=player.story||{chapter:0,finalClaimed:false};player.story.krKingDefeated=true;player.inventory.push("ancient_rune","crystal");saveCharacter(player);announce(`${player.name} zdobywa runę i kryształ po pokonaniu Króla Umarłych!`);}
     const drops={rat:["oak_club","leather_boots"],troll:["wooden_shield","leather_armor"],orc:["rusty_sword","leather_helmet"],dragon:["leather_legs","rusty_sword"],skeleton:["crystal","leather_helmet"],demon:["crystal","ancient_rune"],boss:["ancient_rune","crystal"]};
     const choices=drops[dead.type]||["oak_club"],dropId=choices[Math.floor(Math.random()*choices.length)],drop=itemCatalog[dropId];
     const groundId="g"+nextGroundItemId++;groundItems.set(groundId,{id:groundId,itemId:dropId,name:drop.name,x:dead.x,y:dead.y,zone:dead.zone||"town"});
     announce(`${dead.name} upuszcza przedmiot: ${drop.name}.`);
     if(dead.type==="rat" && player.quest?.ratHunt==="active")player.quest.ratKills=Math.min(3,(player.quest.ratKills||0)+1);
    announce(`${player.name} pokonuje ${dead.name}. Zdobywa ${dead.exp} EXP.`);
     while(player.exp>=player.level*100){player.exp-=player.level*100;player.level++;player.maxHp+=player.vocation==="knight"?15:player.vocation==="paladin"?12:8;player.maxMana+=player.vocation==="knight"?3:player.vocation==="paladin"?7:15;player.hp=player.maxHp;player.mana=player.maxMana;announce(`${player.name} awansuje na poziom ${player.level}!`);}
     setTimeout(()=>{spawnMonster(dead.respawn);broadcast(snapshot());},12000);
    }
   }
   broadcast(snapshot());
  } else if(msg.type==="pickup"){
   if(player.dead)return;
   const item=[...groundItems.values()].filter(it=>(it.zone||"town")===(player.zone||"town")&&Math.abs(it.x-player.x)+Math.abs(it.y-player.y)<=1).sort((a,b)=>Math.abs(a.x-player.x)+Math.abs(a.y-player.y)-Math.abs(b.x-player.x)-Math.abs(b.y-player.y))[0];
   if(!item){send(ws,{type:"system",text:"Podejdź bliżej przedmiotu, aby go podnieść."});return;}
   if(player.inventory.length>=24){send(ws,{type:"system",text:"Plecak jest pełny (limit 24 przedmiotów)."});return;}
   player.inventory.push(item.itemId);groundItems.delete(item.id);
   send(ws,{type:"system",text:`Podnosisz: ${item.name}.`});broadcast(snapshot());
  } else if(msg.type==="equip"){
   if(player.dead)return;
   const itemId=String(msg.itemId||"");
   if(!player.inventory.includes(itemId)||!itemCatalog[itemId])return;
   const item=itemCatalog[itemId],slot=item.slot;
   const previous=player.equipment[slot];
   if(previous)player.inventory.push(previous);
   player.inventory=player.inventory.filter(id=>id!==itemId);
   player.equipment[slot]=itemId;
   const stats=itemStats(player);
   send(ws,{type:"system",text:`Zakładasz: ${item.name}. Bonus: ATK +${item.attack}, DEF +${item.defense}.`});
   broadcast(snapshot());
  } else if(msg.type==="unequip"){
   if(player.dead)return;
   const slot=String(msg.slot||"");
   if(!equipmentSlots.includes(slot)||!player.equipment[slot])return;
   const itemId=player.equipment[slot],item=itemCatalog[itemId];
   player.equipment[slot]=null;player.inventory.push(itemId);
   send(ws,{type:"system",text:`Zdejmujesz: ${item.name}.`});broadcast(snapshot());
  } else if(msg.type==="eat"){
   if(player.dead)return;
   const idx=player.inventory.indexOf(String(msg.itemId||""));
   const food= itemCatalog[String(msg.itemId||"")];
   if(idx<0||!food||!food.food){send(ws,{type:"system",text:"Nie masz tego jedzenia w plecaku."});return;}
   if(player.hunger>=100){send(ws,{type:"system",text:"Nie jesteś głodny."});return;}
   player.inventory.splice(idx,1);player.hunger=Math.min(100,player.hunger+food.food);
   send(ws,{type:"system",text:`Zjadasz ${food.name}. Sytość: ${player.hunger}/100.`});broadcast(snapshot());
  } else if(msg.type==="shop"){
   const npc=npcList.find(n=>n.id==="npc_shop");
   if(Math.abs(npc.x-player.x)+Math.abs(npc.y-player.y)>2){send(ws,{type:"system",text:"Podejdź do Kupca Jana."});return;}
   const goods={bread:5,apple:3,meat:8,wooden_shield:35,rusty_sword:50,health_potion:45,mana_potion:40,great_potion:120};
   if(msg.action==="list"){send(ws,{type:"system",text:"Kupiec: chleb 5 GP, jabłko 3 GP, mięso 8 GP, tarcza 35 GP, miecz 50 GP, mikstura zdrowia 45 GP, many 40 GP, wielka 120 GP. Użyj przycisku SKLEP przy kupcu."});return;}
   const itemId=String(msg.itemId||""),price=goods[itemId];
   if(!price||!itemCatalog[itemId])return;
   if((player.gold||0)<price){send(ws,{type:"system",text:"Masz za mało złota."});return;}
   if(player.inventory.length>=24){send(ws,{type:"system",text:"Plecak jest pełny."});return;}
   player.gold-=price;player.inventory.push(itemId);send(ws,{type:"system",text:`Kupujesz ${itemCatalog[itemId].name} za ${price} gp.`});broadcast(snapshot());
  } else if(msg.type==="party"){
   const nearby=[...players.values()].find(p=>p.id!==player.id&&Math.abs(p.x-player.x)+Math.abs(p.y-player.y)<=3&&p.name.toLowerCase()===String(msg.target||"").toLowerCase());
   if(!nearby){send(ws,{type:"system",text:"Nie znaleziono gracza o tym nicku w promieniu 3 pól."});return;}
   if(msg.action==="invite"){send(nearby.ws,{type:"party_invite",from:player.name});send(ws,{type:"system",text:`Wysłano zaproszenie do ${nearby.name}.`});}
   else if(msg.action==="accept" && nearby.pendingPartyInvite===player.name){const partyId=player.partyId||nearby.partyId||crypto.randomUUID();player.partyId=partyId;nearby.partyId=partyId;player.pendingPartyInvite=null;nearby.pendingPartyInvite=null;announce(`${player.name} i ${nearby.name} tworzą drużynę.`);broadcast(snapshot());}
  } else if(msg.type==="craft"){
   const recipes={wooden_shield:{need:{oak_club:1,leather_armor:1},name:"Drewniana tarcza"},rusty_sword:{need:{oak_club:2,leather_boots:1},name:"Zardzewiały miecz"},leather_armor:{need:{leather_legs:1,leather_boots:1},name:"Skórzana zbroja"},
     iron_sword:{need:{rusty_sword:2,crystal:1},name:"Żelazny miecz"},
     steel_armor:{need:{leather_armor:1,ancient_rune:2},name:"Stalowa zbroja"},
     health_potion:{need:{apple:2,crystal:1},name:"Mikstura zdrowia"},
     mana_potion:{need:{bread:1,crystal:1},name:"Mikstura many"}};
   const id=String(msg.itemId||"");const recipe=recipes[id];if(!recipe||!itemCatalog[id])return send(ws,{type:"system",text:"Nieznany przepis."});
   if(player.inventory.length>=24)return send(ws,{type:"system",text:"Plecak jest pełny."});
   for(const [ingredient,count] of Object.entries(recipe.need)){if(player.inventory.filter(x=>x===ingredient).length<count)return send(ws,{type:"system",text:`Brakuje składnika: ${itemCatalog[ingredient].name} x${count}.`});}
   for(const [ingredient,count] of Object.entries(recipe.need))for(let i=0;i<count;i++)player.inventory.splice(player.inventory.indexOf(ingredient),1);
   player.inventory.push(id);send(ws,{type:"system",text:`Wytworzono: ${recipe.name}.`});broadcast(snapshot());
  } else if(msg.type==="bank"){
   if(player.zone!=="town"||Math.abs(player.x-20)+Math.abs(player.y-14)>5)return send(ws,{type:"system",text:"Depozyt jest dostępny w centrum Thais."});
   const action=String(msg.action||"");
   if(action==="deposit_gold"){const n=Math.floor(Number(msg.amount));if(!Number.isFinite(n)||n<1||n>player.gold)return send(ws,{type:"system",text:"Nieprawidłowa ilość złota."});player.gold-=n;player.bankGold=(player.bankGold||0)+n;}
   else if(action==="withdraw_gold"){const n=Math.floor(Number(msg.amount));if(!Number.isFinite(n)||n<1||n>(player.bankGold||0))return send(ws,{type:"system",text:"Nieprawidłowa ilość złota w banku."});player.bankGold-=n;player.gold=(player.gold||0)+n;}
   else if(action==="deposit_item"){const id=String(msg.itemId||"");const i=player.inventory.indexOf(id);if(i<0)return send(ws,{type:"system",text:"Nie masz tego przedmiotu."});if((player.bank||[]).length>=100)return send(ws,{type:"system",text:"Depozyt jest pełny."});player.inventory.splice(i,1);player.bank.push(id);}
   else if(action==="withdraw_item"){const id=String(msg.itemId||"");const i=(player.bank||[]).indexOf(id);if(i<0)return send(ws,{type:"system",text:"Brak przedmiotu w depozycie."});if(player.inventory.length>=24)return send(ws,{type:"system",text:"Plecak jest pełny."});player.bank.splice(i,1);player.inventory.push(id);}
   else return;send(ws,{type:"system",text:`Bank: ${player.bankGold||0} GP; przedmioty: ${(player.bank||[]).length}.`});broadcast(snapshot());
  } else if(msg.type==="travel"){
   const zone=String(msg.zone||"");if(!["town","forest","cave","catacombs"].includes(zone))return;
    if(zone==="catacombs" && (player.level<12 || !(player.unlockedZones||[]).includes("catacombs")))return send(ws,{type:"system",text:"Katakumby wymagają poziomu 12 i odblokowania fabularnego."});
    player.zone=zone;player.x=20;player.y=14;send(ws,{type:"system",text:`Wkraczasz na teren: ${zoneNames[zone]}.`});broadcast(snapshot());
  } else if(msg.type==="duel"){
   if(msg.action==="challenge"){
    const target=[...players.values()].find(p=>p.id!==player.id&&p.name.toLowerCase()===String(msg.target||"").toLowerCase());
    if(!target)return send(ws,{type:"system",text:"Nie znaleziono zalogowanego gracza."});
    if(target.zone!==player.zone||Math.abs(target.x-player.x)+Math.abs(target.y-player.y)>5)return send(ws,{type:"system",text:"Podejdź do gracza (maksymalnie 5 pól)."});
    target.pendingDuel=player.id;send(target.ws,{type:"duel_invite",from:player.name,fromId:player.id});send(ws,{type:"system",text:`Wysłano wyzwanie do ${target.name}.`});
   }else if(msg.action==="accept"){
    const challenger=players.get(String(msg.fromId||""));if(!challenger||player.pendingDuel!==challenger.id)return send(ws,{type:"system",text:"Wyzwanie jest nieaktualne."});
    const duelId=crypto.randomUUID();player.duelId=duelId;challenger.duelId=duelId;player.pendingDuel=null;announce(`${player.name} przyjmuje pojedynek z ${challenger.name}.`);broadcast(snapshot());
   }
  } else if(msg.type==="attack_player"){
   const target=[...players.values()].find(p=>p.name.toLowerCase()===String(msg.target||"").toLowerCase());
   if(!target||player.dead||target.dead||target.zone!==player.zone||!player.duelId||target.duelId!==player.duelId||target.id===player.id)return send(ws,{type:"system",text:"Atakuj wyłącznie gracza, który zaakceptował Twój pojedynek."});
   if(Math.abs(target.x-player.x)+Math.abs(target.y-player.y)>1)return send(ws,{type:"system",text:"Przeciwnik jest za daleko."});
   if(Date.now()-(player.lastAttack||0)<800)return;player.lastAttack=Date.now();const damage=Math.max(1,vocations[player.vocation].damage+player.level+itemStats(player).attack-itemStats(target).defense);target.hp=Math.max(0,target.hp-damage);
   send(target.ws,{type:"system",text:`${player.name} trafia Cię za ${damage} obrażeń w pojedynku.`});send(ws,{type:"system",text:`Trafiasz ${target.name} za ${damage} obrażeń.`});
   if(target.hp<=0){player.duelId=null;target.duelId=null;target.hp=target.maxHp;target.x=20;target.y=14;announce(`${player.name} wygrywa pojedynek z ${target.name}!`);}broadcast(snapshot());
  } else if(msg.type==="house"){
   const action=String(msg.action||"");
   if(action==="list"){const list=Object.values(houses).map(x=>`${x.id}: ${x.name} — ${x.owner||"wolny"}`).join(" | ");send(ws,{type:"system",text:list||"Brak dostępnych domów."});return;}
   if(action==="buy"){
    const id=String(msg.houseId||"");const h=houses[id];if(!h)return send(ws,{type:"system",text:"Nie znaleziono domu."});
    if(h.owner)return send(ws,{type:"system",text:"Ten dom ma już właściciela."});if(player.houseId)return send(ws,{type:"system",text:"Masz już swój dom."});
    if(player.gold< h.price)return send(ws,{type:"system",text:`Potrzebujesz ${h.price} GP.`});
    player.gold-=h.price;h.owner=player.name;player.houseId=id;saveHouses();saveCharacter(player);send(ws,{type:"system",text:`Kupujesz ${h.name}. Dom jest teraz Twój!`});broadcast(snapshot());return;
   }
   if(action==="leave"){
    const h=houses[player.houseId];if(!h||h.owner!==player.name)return send(ws,{type:"system",text:"Nie posiadasz domu."});h.owner=null;player.houseId=null;saveHouses();saveCharacter(player);send(ws,{type:"system",text:"Oddajesz dom. Zwrot kosztów nie przysługuje."});broadcast(snapshot());return;
   }
   if(action==="info"){const h=houses[player.houseId];send(ws,{type:"system",text:h?`Twój dom: ${h.name}.`:"Nie posiadasz domu."});return;}
  } else if(msg.type==="trade"){
   const action=String(msg.action||"");
   if(action==="offer"){
    const target=[...players.values()].find(p=>p.id!==player.id&&p.name.toLowerCase()===String(msg.target||"").toLowerCase());
    if(!target||target.zone!==player.zone||Math.abs(target.x-player.x)+Math.abs(target.y-player.y)>4)return send(ws,{type:"system",text:"Handel wymaga obecności gracza w odległości 4 pól."});
    const itemId=String(msg.itemId||"");const amount=Math.floor(Number(msg.gold||0));
    if(!itemCatalog[itemId]||!player.inventory.includes(itemId)||!Number.isFinite(amount)||amount<0||amount>player.gold)return send(ws,{type:"system",text:"Nieprawidłowa oferta. Wskaż posiadany przedmiot i poprawną ilość GP."});
    const id=crypto.randomUUID();tradeOffers.set(id,{id,from:player.id,to:target.id,itemId,gold:amount,expires:Date.now()+60000});
    send(target.ws,{type:"trade_invite",id,from:player.name,itemId,gold:amount});send(ws,{type:"system",text:`Wysłano ofertę handlu do ${target.name}.`});return;
   }
   if(action==="accept"){
    const offer=tradeOffers.get(String(msg.offerId||""));if(!offer||offer.to!==player.id||offer.expires<Date.now())return send(ws,{type:"system",text:"Oferta wygasła lub nie istnieje."});
    const from=players.get(offer.from);if(!from||!from.inventory.includes(offer.itemId)||from.gold<offer.gold||player.inventory.length>=24)return send(ws,{type:"system",text:"Nie można zrealizować wymiany — stan ekwipunku lub złota się zmienił."});
    from.inventory.splice(from.inventory.indexOf(offer.itemId),1);from.gold-=offer.gold;player.inventory.push(offer.itemId);player.gold+=offer.gold;tradeOffers.delete(offer.id);
    send(from.ws,{type:"system",text:`${player.name} zaakceptował wymianę.`});send(ws,{type:"system",text:`Wymiana z ${from.name} zakończona.`});broadcast(snapshot());return;
   }
   if(action==="cancel"){for(const [id,o] of tradeOffers)if(o.from===player.id||o.to===player.id)tradeOffers.delete(id);send(ws,{type:"system",text:"Anulowano oczekujące oferty handlu."});return;}
  } else if(msg.type==="boss"){
   const boss=[...monsters.values()].find(m=>m.boss&&(m.zone||"town")===(player.zone||"town"));send(ws,{type:"system",text:boss?`Boss: ${boss.name} — ${boss.hp}/${boss.maxHp} HP. Poziom wyzwania: bardzo wysoki.`:"W tym regionie nie ma aktywnego bossa."});return;
  } else if(msg.type==="mount"){
   const action=String(msg.action||"");
   const mounts={pony:{name:"Kucyk",price:300},wolf:{name:"Wilczy rumak",price:900},stag:{name:"Leśny jeleń",price:1600}};
   if(action==="list"){send(ws,{type:"system",text:"Wierzchowce: pony (300 GP), wolf (900 GP), stag (1600 GP). Kup: buy; Załóż: equip; Zsiądź: dismount."});return;}
   if(action==="buy"){const id=String(msg.mountId||"");const item=mounts[id];if(!item)return send(ws,{type:"system",text:"Nieznany wierzchowiec."});player.mounts=player.mounts||[];if(player.mounts.includes(id))return send(ws,{type:"system",text:"Masz już tego wierzchowca."});if(player.gold<item.price)return send(ws,{type:"system",text:`Potrzebujesz ${item.price} GP.`});player.gold-=item.price;player.mounts.push(id);saveCharacter(player);send(ws,{type:"system",text:`Kupujesz: ${item.name}.`});}
   else if(action==="equip"){const id=String(msg.mountId||"");if(!(player.mounts||[]).includes(id))return send(ws,{type:"system",text:"Nie posiadasz tego wierzchowca."});player.mount=id;send(ws,{type:"system",text:`Wsiadasz na: ${mounts[id].name}.`});}
   else if(action==="dismount"){player.mount=null;send(ws,{type:"system",text:"Zsiadasz z wierzchowca."});}
   else if(action==="owned"){send(ws,{type:"system",text:`Twoje wierzchowce: ${(player.mounts||[]).join(", ")||"brak"}.`});}
   saveCharacter(player);broadcast(snapshot());
  } else if(msg.type==="achievements"){
   const list=earnedAchievements(player);player.achievements=list;saveCharacter(player);
   send(ws,{type:"system",text:`OSIĄGNIĘCIA (${list.length}): ${list.join(", ")||"Jeszcze brak. Awansuj, zdobywaj złoto i kończ zadania."}`});return;
  } else if(msg.type==="leaderboard"){
   const rows=Object.values(savedCharacters).concat([...players.values()].map(p=>{const {ws,...x}=p;return x;}));
   const unique=new Map();for(const p of rows)if(p?.name)unique.set(p.name.toLowerCase(),p);
   const sorted=[...unique.values()].sort((a,b)=>(b.level||1)-(a.level||1)||(b.exp||0)-(a.exp||0));
   send(ws,{type:"system",text:"RANKING IMPERIUM — "+sorted.slice(0,10).map((p,i)=>`${i+1}. ${p.name} — poziom ${p.level||1}`).join(" | ")});return;
  } else if(msg.type==="magic_train"){
   const cost=250+((player.magicLevel||0)*250);
   if(player.magicLevel>=5)return send(ws,{type:"system",text:"Osiągnięto maksymalny poziom szkolenia magii."});
   if(player.gold<cost)return send(ws,{type:"system",text:`Trening magii kosztuje ${cost} GP.`});
   player.gold-=cost;player.magicLevel=(player.magicLevel||0)+1;saveCharacter(player);
   send(ws,{type:"system",text:`Trening zakończony. Poziom magii ${player.magicLevel}; moc czarów wzrosła.`});broadcast(snapshot());return;
  } else if(msg.type==="event"){
   const action=String(msg.action||"");
   if(action==="status"){send(ws,{type:"system",text:worldEvent.active?`Event: ${worldEvent.name}. Uczestnicy: ${worldEvent.participants.length}.`:"Aktualnie brak aktywnego eventu."});return;}
   if(action==="start"){if(worldEvent.active)return send(ws,{type:"system",text:"Event już trwa."});worldEvent={active:true,name:"Najazd potworów",participants:[],startedAt:Date.now()};announce("Rozpoczyna się event: Najazd potworów! Wpisz join, aby dołączyć.");return;}
   if(action==="join"){if(!worldEvent.active)return send(ws,{type:"system",text:"Nie ma aktywnego eventu."});if(!worldEvent.participants.includes(player.id))worldEvent.participants.push(player.id);send(ws,{type:"system",text:"Dołączasz do eventu. Po zakończeniu odbierzesz nagrodę."});return;}
   if(action==="finish"){if(!worldEvent.active)return send(ws,{type:"system",text:"Brak aktywnego eventu."});const winners=worldEvent.participants.map(id=>players.get(id)).filter(Boolean);for(const p of winners){p.exp+=100;p.gold+=50;send(p.ws,{type:"system",text:"Event ukończony! +100 EXP i +50 GP."});saveCharacter(p);}announce(`Event zakończony. Nagrodzono ${winners.length} uczestników.`);worldEvent={active:false,name:"",participants:[],startedAt:0};broadcast(snapshot());return;}
  } else if(msg.type==="mail"){
   const action=String(msg.action||"");mailboxes[player.name.toLowerCase()]=mailboxes[player.name.toLowerCase()]||[];
   if(action==="send"){const target=String(msg.target||"").trim().toLowerCase();const text=String(msg.text||"").trim().slice(0,180);if(!target||!text)return send(ws,{type:"system",text:"Podaj odbiorcę i treść wiadomości."});if(!savedCharacters[target]&&![...players.values()].some(p=>p.name.toLowerCase()===target))return send(ws,{type:"system",text:"Nie znaleziono takiej postaci."});mailboxes[target]=mailboxes[target]||[];mailboxes[target].push({from:player.name,text,at:Date.now()});saveMail();send(ws,{type:"system",text:"Wiadomość wysłana do skrzynki pocztowej."});return;}
   if(action==="read"){const box=mailboxes[player.name.toLowerCase()]||[];send(ws,{type:"system",text:box.length?box.slice(-8).map((x,i)=>`${i+1}. ${x.from}: ${x.text}`).join(" | "):"Skrzynka jest pusta."});return;}
   if(action==="clear"){mailboxes[player.name.toLowerCase()]=[];saveMail();send(ws,{type:"system",text:"Skrzynka pocztowa wyczyszczona."});return;}
  } else if(msg.type==="daily"){
   const today=new Date().toISOString().slice(0,10);
   if(player.dailyDate===today)return send(ws,{type:"system",text:"Dzisiejsza nagroda została już odebrana."});
   const yesterday=new Date(Date.now()-86400000).toISOString().slice(0,10);
   player.dailyStreak=player.dailyDate===yesterday?(player.dailyStreak||0)+1:1;
   player.dailyDate=today;const reward=50+Math.min(200,player.dailyStreak*10);player.gold+=reward;player.exp+=25;
   saveCharacter(player);send(ws,{type:"system",text:`Nagroda dzienna: +${reward} GP i +25 EXP. Seria: ${player.dailyStreak} dni.`});broadcast(snapshot());return;
  } else if(msg.type==="bestiary"){
   const rows=Object.entries(player.bestiary||{}).sort((a,b)=>b[1]-a[1]);
   send(ws,{type:"system",text:"BESTIARIUSZ: "+(rows.length?rows.map(([id,n])=>`${id}: ${n}`).join(" | "):"Nie pokonano jeszcze żadnych potworów.")});return;
  } else if(msg.type==="teleport"){
   const cost=100;const zone=String(msg.zone||player.zone||"town");
   if(!["town","forest","cave","catacombs"].includes(zone))return send(ws,{type:"system",text:"Nieznany region."});
    if(zone==="catacombs" && (player.level<12 || !(player.unlockedZones||[]).includes("catacombs")))return send(ws,{type:"system",text:"Katakumby odblokujesz po osiągnięciu 12 poziomu i ukończeniu rozdziału II."});
   if(player.gold<cost)return send(ws,{type:"system",text:"Teleport kosztuje 100 GP."});
   player.gold-=cost;player.zone=zone;player.x=20;player.y=14;saveCharacter(player);
   send(ws,{type:"system",text:`Teleportujesz się do: ${zoneNames[zone]}. (-100 GP)`});broadcast(snapshot());return;
  } else if(msg.type==="guild"){
   const action=String(msg.action||"");
   if(action==="create"){
    const name=String(msg.name||"").trim().replace(/[^a-zA-Z0-9 _-]/g,"").slice(0,20);
    if(name.length<3)return send(ws,{type:"system",text:"Nazwa gildii musi mieć 3–20 znaków."});
    if(player.guildId)return send(ws,{type:"system",text:"Jesteś już w gildii."});
    if(Object.values(guilds).some(g=>g.name.toLowerCase()===name.toLowerCase()))return send(ws,{type:"system",text:"Taka gildia już istnieje."});
    const id=crypto.randomUUID();guilds[id]={id,name,leader:player.name,members:[player.name],invites:[]};player.guildId=id;saveGuilds();announce(`${player.name} zakłada gildię ${name}.`);broadcast(snapshot());
   }else if(action==="invite"){
    const g=guilds[player.guildId];if(!g||g.leader!==player.name)return send(ws,{type:"system",text:"Tylko lider gildii może zapraszać."});
    const target=[...players.values()].find(p=>p.name.toLowerCase()===String(msg.target||"").toLowerCase());if(!target)return send(ws,{type:"system",text:"Gracz musi być zalogowany."});
    if(target.guildId)return send(ws,{type:"system",text:"Ten gracz należy już do gildii."});
    if(!g.invites.includes(target.name))g.invites.push(target.name);saveGuilds();send(target.ws,{type:"guild_invite",guildId:g.id,guildName:g.name,from:player.name});send(ws,{type:"system",text:`Zaproszono ${target.name} do gildii ${g.name}.`});
   }else if(action==="accept"){
    const g=guilds[String(msg.guildId||"")];if(!g||!g.invites.includes(player.name)||player.guildId)return send(ws,{type:"system",text:"Zaproszenie jest nieaktualne."});g.invites=g.invites.filter(n=>n!==player.name);g.members.push(player.name);player.guildId=g.id;saveGuilds();announce(`${player.name} dołącza do gildii ${g.name}.`);broadcast(snapshot());
   }else if(action==="leave"){
    const g=guilds[player.guildId];if(!g)return send(ws,{type:"system",text:"Nie należysz do gildii."});
    if(g.leader===player.name){delete guilds[g.id];for(const p of players.values())if(p.guildId===g.id)p.guildId=null;announce(`Gildia ${g.name} zostaje rozwiązana.`);}else{g.members=g.members.filter(n=>n!==player.name);player.guildId=null;announce(`${player.name} opuszcza gildię ${g.name}.`);}saveGuilds();broadcast(snapshot());
   }else if(action==="info"){
    const g=guilds[player.guildId];send(ws,{type:"system",text:g?`Gildia ${g.name} | Lider: ${g.leader} | Członkowie: ${g.members.join(", ")}`:"Nie należysz do gildii."});
   }
  } else if(msg.type==="quest"){
   const action=String(msg.action||"");
   if(action==="list"){send(ws,{type:"system",text:`Zadania: Wilcza plaga ${player.quest?.wolfHunt||"not_started"} (${player.quest?.wolfKills||0}/5); Mroczna krypta ${player.quest?.caveHunt||"not_started"} (${player.quest?.caveKills||0}/5).`});return;}
   if(action==="start_wolf"){if(player.quest.wolfHunt==="completed")return send(ws,{type:"system",text:"To zadanie masz już ukończone."});player.quest.wolfHunt="active";player.quest.wolfKills=player.quest.wolfKills||0;send(ws,{type:"system",text:"Nowe zadanie: pokonaj 5 wilków w Zaczarowanym Lesie."});return;}
   if(action==="claim_wolf"){if(player.quest.wolfHunt!=="active"||player.quest.wolfKills<5)return send(ws,{type:"system",text:"Nie masz jeszcze 5 wilczych trofeów."});player.quest.wolfHunt="completed";player.exp+=120;player.gold+=75;send(ws,{type:"system",text:"Zadanie ukończone! +120 EXP i +75 GP."});broadcast(snapshot());return;}
   if(action==="start_cave"){if(player.quest.caveHunt==="completed")return send(ws,{type:"system",text:"To zadanie masz już ukończone."});player.quest.caveHunt="active";player.quest.caveKills=player.quest.caveKills||0;send(ws,{type:"system",text:"Nowe zadanie: pokonaj 5 szkieletów lub demonów w Mrocznej Jaskini."});return;}
   if(action==="claim_cave"){if(player.quest.caveHunt!=="active"||player.quest.caveKills<5)return send(ws,{type:"system",text:"Brakuje potworów do ukończenia zadania."});player.quest.caveHunt="completed";player.exp+=250;player.gold+=150;send(ws,{type:"system",text:"Zadanie ukończone! +250 EXP i +150 GP."});broadcast(snapshot());return;}
  } else if(msg.type==="use_item"){
   if(player.dead)return;
   const id=String(msg.itemId||"");const idx=player.inventory.indexOf(id);const item=itemCatalog[id];
   if(idx<0||!item||(!item.heal&&!item.mana))return send(ws,{type:"system",text:"Nie masz takiej mikstury."});
   const oldHp=player.hp,oldMana=player.mana;
   player.hp=Math.min(player.maxHp,player.hp+(item.heal||0));player.mana=Math.min(player.maxMana,player.mana+(item.mana||0));
   if(player.hp===oldHp&&player.mana===oldMana)return send(ws,{type:"system",text:"Twoje HP i MP są już pełne."});
   player.inventory.splice(idx,1);saveCharacter(player);
   send(ws,{type:"system",text:`Używasz ${item.name}. Odzyskano ${player.hp-oldHp} HP i ${player.mana-oldMana} MP.`});broadcast(snapshot());return;
  } else if(msg.type==="character"){
   const sk=player.skills||{melee:1,defense:1,magic:1};
   send(ws,{type:"system",text:`KARTA POSTACI — ${player.name} | ${player.vocationName} | Poziom ${player.level} (${player.exp}/${player.level*100} EXP) | HP ${player.hp}/${player.maxHp} | MP ${player.mana}/${player.maxMana} | GP ${player.gold} | Bank ${player.bankGold||0} | Umiejętności: walka ${sk.melee}, obrona ${sk.defense}, magia ${sk.magic} | Tytuł: ${player.title||"Nowicjusz"} | Towarzysz: ${player.pet||"brak"}.`});return;
  } else if(msg.type==="daily_task"){
   const day=new Date().toISOString().slice(0,10);
   const tasks=[{id:"rats",name:"Deratyzacja",type:"rat",goal:5,reward:90},{id:"wolves",name:"Leśny łowca",type:"wolf",goal:3,reward:140},{id:"undead",name:"Czystka nieumarłych",type:"skeleton",goal:3,reward:180},{id:"orcs",name:"Orcza straż",type:"orc",goal:4,reward:160}];
   if(!player.dailyTask||player.dailyTask.day!==day){const t=tasks[Math.floor((Date.now()/86400000+player.level)%tasks.length)];player.dailyTask={day,...t,kills:0,claimed:false};saveCharacter(player);}
   const t=player.dailyTask;
   if(msg.action==="claim"){if(t.claimed||t.kills<t.goal)return send(ws,{type:"system",text:`Zadanie dzienne: ${t.name} (${t.kills}/${t.goal}).`});t.claimed=true;player.gold+=t.reward;player.exp+=75;saveCharacter(player);send(ws,{type:"system",text:`Zadanie dzienne ukończone! +${t.reward} GP i +75 EXP.`});}
   else send(ws,{type:"system",text:`ZADANIE DNIA: ${t.name} — pokonaj ${t.goal} ${t.type}. Postęp ${t.kills}/${t.goal}. Nagroda ${t.reward} GP +75 EXP. ${t.claimed?"Nagroda odebrana.":"Użyj claim po ukończeniu."}`});
   broadcast(snapshot());return;
  } else if(msg.type==="skill_train"){
   const skill=String(msg.skill||"");if(!["melee","defense","magic"].includes(skill))return send(ws,{type:"system",text:"Wybierz: melee, defense lub magic."});
   player.skills=player.skills||{melee:1,defense:1,magic:1};const current=player.skills[skill]||1;const cost=current*180;
   if(current>=20)return send(ws,{type:"system",text:"Ta umiejętność osiągnęła maksymalny poziom 20."});
   if(player.gold<cost)return send(ws,{type:"system",text:`Trening kosztuje ${cost} GP.`});
   player.gold-=cost;player.skills[skill]=current+1;saveCharacter(player);send(ws,{type:"system",text:`Trening ukończony: ${skill} ${current} → ${current+1}.`});broadcast(snapshot());return;
  } else if(msg.type==="title"){
   player.titles=player.titles||["Nowicjusz"];
   if(msg.action==="equip"){const t=String(msg.name||"");if(!player.titles.includes(t))return send(ws,{type:"system",text:"Nie posiadasz tego tytułu."});player.title=t;saveCharacter(player);send(ws,{type:"system",text:`Ustawiono tytuł: ${t}.`});}
   else {if(player.level>=5&&!player.titles.includes("Pogromca"))player.titles.push("Pogromca");if(player.level>=12&&!player.titles.includes("Weteran"))player.titles.push("Weteran");if((player.bestiary?.boss||0)>0&&!player.titles.includes("Zabójca bossów"))player.titles.push("Zabójca bossów");if(player.story?.finalClaimed&&!player.titles.includes("Obrońca Imperium"))player.titles.push("Obrońca Imperium");send(ws,{type:"system",text:`TWOJE TYTUŁY: ${player.titles.join(", ")}.`});}
   saveCharacter(player);return;
  } else if(msg.type==="pet"){
   const pets={wolf:{name:"Wilczy szczeniak",price:600,bonus:2},fox:{name:"Leśny lis",price:1200,bonus:3},dragonling:{name:"Smoczy pisklak",price:3000,bonus:5}};player.pets=player.pets||[];const action=String(msg.action||"list");
   if(action==="buy"){const id=String(msg.petId||"");const pet=pets[id];if(!pet)return send(ws,{type:"system",text:"Nieznany towarzysz."});if(player.pets.includes(id))return send(ws,{type:"system",text:"Masz już tego towarzysza."});if(player.gold<pet.price)return send(ws,{type:"system",text:`Potrzebujesz ${pet.price} GP.`});player.gold-=pet.price;player.pets.push(id);saveCharacter(player);send(ws,{type:"system",text:`Adoptujesz: ${pet.name}.`});}
   else if(action==="equip"){const id=String(msg.petId||"");if(!player.pets.includes(id)||!pets[id])return send(ws,{type:"system",text:"Nie posiadasz tego towarzysza."});player.pet=id;saveCharacter(player);send(ws,{type:"system",text:`Twój towarzysz: ${pets[id].name}. Bonus ATK +${pets[id].bonus}.`});}
   else if(action==="dismiss"){player.pet=null;saveCharacter(player);send(ws,{type:"system",text:"Towarzysz odpoczywa."});}
   else send(ws,{type:"system",text:"TOWARZYSZE: wolf 600 GP, fox 1200 GP, dragonling 3000 GP. Użyj buy/equip/dismiss."});
   broadcast(snapshot());return;
  } else if(msg.type==="market"){
   const file=path.join(DATA_DIR,"market.json");let listings=[];try{listings=JSON.parse(fs.readFileSync(file,"utf8"));}catch{}
   const action=String(msg.action||"list");
   if(action==="list"){send(ws,{type:"system",text:listings.length?"RYNEK: "+listings.map(x=>`${x.id}: ${x.itemId} — ${x.price} GP (${x.seller})`).join(" | "):"Rynek jest pusty."});return;}
   if(action==="sell"){const id=String(msg.itemId||"");const price=Math.floor(Number(msg.price));const idx=player.inventory.indexOf(id);if(!itemCatalog[id]||idx<0||!Number.isFinite(price)||price<1||price>1000000)return send(ws,{type:"system",text:"Nieprawidłowy przedmiot lub cena."});player.inventory.splice(idx,1);listings.push({id:crypto.randomUUID().slice(0,8),itemId:id,price,seller:player.name});fs.writeFileSync(file,JSON.stringify(listings,null,2));saveCharacter(player);send(ws,{type:"system",text:"Wystawiono przedmiot na rynku."});return;}
   if(action==="buy"){const id=String(msg.listingId||"");const i=listings.findIndex(x=>x.id===id);if(i<0)return send(ws,{type:"system",text:"Oferta nie istnieje."});const offer=listings[i];if(offer.seller===player.name)return send(ws,{type:"system",text:"Nie możesz kupić własnej oferty."});if(player.gold<offer.price||player.inventory.length>=24)return send(ws,{type:"system",text:"Za mało GP lub pełny plecak."});const seller=[...players.values()].find(p=>p.name===offer.seller);if(seller){seller.gold+=offer.price;saveCharacter(seller);}else{const savedSeller=savedCharacters[String(offer.seller).toLowerCase()];if(savedSeller){savedSeller.gold=(savedSeller.gold||0)+offer.price;fs.writeFileSync(SAVE_FILE,JSON.stringify(savedCharacters,null,2));}}player.gold-=offer.price;player.inventory.push(offer.itemId);listings.splice(i,1);fs.writeFileSync(file,JSON.stringify(listings,null,2));saveCharacter(player);send(ws,{type:"system",text:`Kupiono ${itemCatalog[offer.itemId]?.name||offer.itemId} za ${offer.price} GP.`});return;}
   } else if(msg.type==="story"){
   player.story=player.story||{chapter:0,finalClaimed:false};const chapter=player.story.chapter||0;const action=String(msg.action||"status");
   if(action==="status"){send(ws,{type:"system",text:`GŁÓWNA FABUŁA — Rozdział ${chapter}/3. I: Strażnik Thais. II: Sekret katakumb (poziom 12). III: Król Umarłych.`});return;}
   if(action==="advance"&&chapter===0){if(player.level<5||player.quest?.ratHunt!=="completed")return send(ws,{type:"system",text:"Najpierw osiągnij poziom 5 i ukończ zadanie Strażnika Marka."});player.story.chapter=1;player.exp+=150;player.gold+=100;saveCharacter(player);send(ws,{type:"system",text:"ROZDZIAŁ I ukończony! +150 EXP, +100 GP. Strażnik wskazuje wejście do katakumb."});return;}
   if(action==="advance"&&chapter===1){if(player.level<12)return send(ws,{type:"system",text:"Potrzebujesz poziomu 12, aby wejść do katakumb."});player.unlockedZones=player.unlockedZones||["town","forest","cave"];if(!player.unlockedZones.includes("catacombs"))player.unlockedZones.push("catacombs");player.story.chapter=2;player.exp+=300;player.gold+=250;saveCharacter(player);send(ws,{type:"system",text:"ROZDZIAŁ II ukończony! Odblokowano Zapomniane Katakumby. +300 EXP, +250 GP."});return;}
   if(action==="advance"&&chapter===2){if(!player.story.krKingDefeated)return send(ws,{type:"system",text:"Pokonaj Króla Umarłych w Zapomnianych Katakumbach, aby zakończyć opowieść."});if(player.story.finalClaimed)return send(ws,{type:"system",text:"Fabuła została już ukończona."});player.story.chapter=3;player.story.finalClaimed=true;player.gold+=2500;player.exp+=1500;player.titles=player.titles||["Nowicjusz"];if(!player.titles.includes("Obrońca Imperium"))player.titles.push("Obrońca Imperium");player.title="Obrońca Imperium";saveCharacter(player);send(ws,{type:"system",text:"ZWYCIĘSTWO! Pokonałeś Króla Umarłych i ocaliłeś Imperium. +2500 GP, +1500 EXP. Zdobywasz tytuł Obrońca Imperium."});announce(`${player.name} ukończył główną fabułę IMPERIUM!`);return;}
   send(ws,{type:"system",text:"Nie można teraz przejść dalej w fabule."});return;
  } else if(msg.type==="talk"){

   const npc=npcList.find(n=>n.id===String(msg.npcId||"npc_guide"));
   if(!npc||Math.abs(npc.x-player.x)+Math.abs(npc.y-player.y)>2){send(ws,{type:"system",text:"Podejdź bliżej NPC, aby porozmawiać."});return;}
   if(player.quest.ratHunt==="not_started"){
    player.quest.ratHunt="active";player.quest.ratKills=0;
    send(ws,{type:"system",text:"Strażnik Marek: Witaj! Pokonaj 3 szczury w okolicy, a otrzymasz nagrodę. Zadanie rozpoczęte."});
   }else if(player.quest.ratHunt==="active" && player.quest.ratKills>=3){
    player.quest.ratHunt="completed";player.exp+=30;player.inventory.push("bread");
    send(ws,{type:"system",text:"Strażnik Marek: Dobra robota! Otrzymujesz 30 EXP i chleb. Zadanie ukończone."});
   }else if(player.quest.ratHunt==="active")send(ws,{type:"system",text:`Strażnik Marek: Pokonaj jeszcze ${3-(player.quest.ratKills||0)} szczury.`});
   else send(ws,{type:"system",text:"Strażnik Marek: Dziękuję za pomoc, bohaterze!"});
   broadcast(snapshot());
  } else if(msg.type==="chat"){
   const text=String(msg.text||"").trim().slice(0,180);if(text)broadcast({type:"chat",name:player.name,text});
  }
 });
 ws.on("close",()=>{if(player){saveCharacter(player);players.delete(player.id);announce(`${player.name} opuszcza Imperium.`);broadcast(snapshot());}});
});
// Potwory atakują graczy znajdujących się na sąsiednim polu.
setInterval(()=>{
 const now=Date.now();
 for(const m of monsters.values()){
  const target=[...players.values()].filter(p=>!p.dead&&(p.zone||"town")===(m.zone||"town")&&Math.abs(p.x-m.x)+Math.abs(p.y-m.y)<=1)
   .sort((a,b)=>(Math.abs(a.x-m.x)+Math.abs(a.y-m.y))-(Math.abs(b.x-m.x)+Math.abs(b.y-m.y)))[0];
  if(!target)continue;
  if(!m.nextAttack)m.nextAttack=now+500;
  if(now<m.nextAttack)continue;
  m.nextAttack=now+(m.type==="rat"?1800:m.type==="dragon"?2200:2000);
  const base=m.type==="rat"?4:m.type==="troll"?11:m.type==="orc"?13:m.type==="wolf"?9:m.type==="skeleton"?16:m.type==="demon"?24:m.type==="boss"?42:28;
  const defense=itemStats(target).defense;
  const damage=Math.max(1,base-defense);
  target.hp=Math.max(0,target.hp-damage);
  send(target.ws,{type:"system",text:`${m.name} atakuje Cię za ${damage} obrażeń (DEF ${defense}).`});
  if(target.hp<=0){
   target.dead=true;target.x=20;target.y=14;
   announce(`${target.name} zostaje pokonany. Odrodzenie nastąpi za 5 sekund.`);
   setTimeout(()=>{if(players.has(target.id)&&target.dead)respawnPlayer(target);},5000);
  }
 }
 broadcast(snapshot());
},500);
setInterval(()=>{
 for(const p of players.values()){
  if(!p.dead){
   p.hunger=Math.max(0,(p.hunger??100)-1);
   if(p.hunger>0){p.hp=Math.min(p.maxHp,p.hp+1);p.mana=Math.min(p.maxMana,p.mana+1);}
   else if(Date.now()-(p.lastHungerDamage||0)>10000){p.hp=Math.max(1,p.hp-1);p.lastHungerDamage=Date.now();}
  }
  saveCharacter(p);send(p.ws,snapshot(p.zone));
 }
},15000);
if(!Object.keys(houses).length){houses.house_01={id:"house_01",name:"Domek przy rynku",price:5000,owner:null};houses.house_02={id:"house_02",name:"Leśna chata",price:7500,owner:null};houses.house_03={id:"house_03",name:"Kamienny dom",price:10000,owner:null};saveHouses();}
server.listen(PORT,()=>console.log(`IMPERIUM Android server działa na porcie ${PORT}`));
