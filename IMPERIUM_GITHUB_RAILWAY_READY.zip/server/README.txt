IMPERIUM — serwer testowy 0.4
Wymagania: Node.js 18+
Uruchomienie:
  cd server
  npm install
  npm start
Serwer nasłuchuje domyślnie na porcie 8080 i obsługuje WebSocket.
W kliencie Android wpisz ws://ADRES_IP_SERWERA:8080 w sieci lokalnej.
Dla publicznego serwera skonfiguruj domenę, TLS/WSS, zaporę i trwałą bazę danych.
To prototyp: brak rejestracji z hasłem, trwałego zapisu postaci, walki i NPC.
