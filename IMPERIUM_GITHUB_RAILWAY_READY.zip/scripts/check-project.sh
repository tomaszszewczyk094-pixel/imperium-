#!/usr/bin/env sh
set -eu
node --check server/server.js
node --check app/src/main/assets/client.js
python3 - <<'PY'
import xml.etree.ElementTree as ET
ET.parse('app/src/main/AndroidManifest.xml')
print('AndroidManifest.xml: OK')
PY
for f in app/src/main/assets/index.html app/src/main/assets/style.css app/src/main/assets/imperium-town.png app/src/main/assets/knight-sprites.png; do
  test -s "$f"
done
printf '%s\n' 'Podstawowa kontrola projektu: OK'
